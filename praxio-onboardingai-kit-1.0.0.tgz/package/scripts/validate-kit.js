#!/usr/bin/env node
'use strict';

const fs = require('fs');
const path = require('path');

const ROOT = path.resolve(__dirname, '..');
let errors = 0;

function check(filePath, label) {
  const full = path.join(ROOT, filePath);
  if (!fs.existsSync(full)) {
    console.error(`  MISSING: ${label || filePath}`);
    errors++;
  } else {
    console.log(`  OK: ${label || filePath}`);
  }
}

console.log('\nValidating @praxio/onboardingai-kit structure...\n');

// CLI entry point
check('bin/cli.js', 'bin/cli.js');

// Claude config
check('.claude/oai-kit.md', '.claude/oai-kit.md');
check('.claude/agents/bug-investigator.md', 'agents/bug-investigator');
check('.claude/agents/builder-agent.md', 'agents/builder-agent');
check('.claude/agents/pr-generator.md', 'agents/pr-generator');
check('.claude/agents/pr-reviewer.md', 'agents/pr-reviewer');
check('.claude/agents/release-agent.md', 'agents/release-agent');
check('.claude/agents/learning-agent.md', 'agents/learning-agent');
check('.claude/agents/test-validator.md', 'agents/test-validator');
check('.claude/agents/architecture-agent.md', 'agents/architecture-agent');
check('.claude/agents/azure-card-refiner.md', 'agents/azure-card-refiner');
check('.claude/agents/impact-analyzer.md', 'agents/impact-analyzer');

// Commands
check('.claude/commands/analyze-bug.md', 'commands/analyze-bug');
check('.claude/commands/generate-fix.md', 'commands/generate-fix');
check('.claude/commands/open-pr.md', 'commands/open-pr');
check('.claude/commands/run-regression.md', 'commands/run-regression');
check('.claude/commands/release-check.md', 'commands/release-check');
check('.claude/commands/feature.md', 'commands/feature');
check('.claude/commands/refine-card.md', 'commands/refine-card');
check('.claude/commands/review-pr.md', 'commands/review-pr');
check('.claude/commands/update-speckit.md', 'commands/update-speckit');
check('.claude/commands/bootstrap-repo.md', 'commands/bootstrap-repo');

// Policies
check('.claude/policies/security-policy.md', 'policies/security');
check('.claude/policies/release-policy.md', 'policies/release');
check('.claude/policies/production-policy.md', 'policies/production');
check('.claude/policies/branch-naming.md', 'policies/branch-naming');
check('.claude/policies/coding-principles.md', 'policies/coding-principles');

// Speckit skeleton
check('.speckit/domain/system-overview.md', 'speckit/domain/system-overview');
check('.speckit/domain/naming-guide.md', 'speckit/domain/naming-guide');
check('.speckit/domain/diagnostic-guide.md', 'speckit/domain/diagnostic-guide');
check('.speckit/architecture/architecture-overview.md', 'speckit/architecture/overview');
check('.speckit/architecture/risk-map.md', 'speckit/architecture/risk-map');
check('.speckit/known-issues/known-issues.md', 'speckit/known-issues');
check('.speckit/known-issues/anti-patterns.md', 'speckit/anti-patterns');
check('.speckit/decisions/adr-registry.md', 'speckit/adr-registry');
check('.speckit/business-rules/business-rules.md', 'speckit/business-rules');
check('.speckit/incidents/metrics-feed.jsonl', 'speckit/metrics-feed');

// oai-flow template
check('.oai-flow/templates/bugreport-template.md', 'oai-flow/bugreport-template');
check('.oai-flow/templates/pr-template.md', 'oai-flow/pr-template');

// MCP template
check('.mcp.json.template', '.mcp.json.template');

// CLAUDE.md
check('CLAUDE.md', 'CLAUDE.md');

console.log(`\n${errors === 0 ? '✅ All checks passed.' : `❌ ${errors} file(s) missing.`}\n`);
process.exit(errors === 0 ? 0 : 1);
