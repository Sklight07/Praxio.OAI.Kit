@.claude/oai-kit.md
