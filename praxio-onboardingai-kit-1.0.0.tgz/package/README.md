# @praxio/onboardingai-kit

Kit de IA para devs Praxio — onboarding de repositórios, refinamento de cards, bug flow e desenvolvimento de features com **Claude Code** e **Azure DevOps**.

> **Humans Decide. Agents Execute.**  
> O kit nunca avança sozinho. Em cada etapa crítica ele para, apresenta o que encontrou e aguarda sua aprovação antes de continuar.

---

## Índice

- [Pré-requisitos](#pré-requisitos)
- [Instalação](#instalação)
- [Configuração do MCP](#configuração-do-mcp)
- [Primeiros passos](#primeiros-passos)
- [Comandos CLI](#comandos-cli)
- [Slash Commands](#slash-commands)
- [Fluxos de trabalho](#fluxos-de-trabalho)
- [Padrões da Praxio](#padrões-da-praxio)
- [Agentes disponíveis](#agentes-disponíveis)
- [O Speckit — memória institucional](#o-speckit--memória-institucional)
- [Múltiplos repositórios](#múltiplos-repositórios)
- [Políticas e hard stops](#políticas-e-hard-stops)
- [Estrutura de arquivos](#estrutura-de-arquivos)
- [Configuração local](#configuração-local)
- [Atualizar o kit](#atualizar-o-kit)
- [Perguntas frequentes](#perguntas-frequentes)

---

## Pré-requisitos

- **Node.js** >= 18
- **Claude Code** instalado (`npm install -g @anthropic-ai/claude-code`)
- **Azure CLI** (`az`) instalado e autenticado (`az login`) — ou um Personal Access Token do Azure DevOps
- Acesso ao Azure DevOps da Praxio

---

## Instalação

Execute dentro do repositório onde quer instalar o kit:

```bash
npx @praxio/onboardingai-kit init
```

O que acontece:
- Copia `.claude/`, `scripts/` e `docs/` para o repositório (sempre atualizados com o kit).
- Cria `.speckit/` e `.oai-flow/` se não existirem (preservados se já existirem — são seus dados).
- Injeta `@.claude/oai-kit.md` no `CLAUDE.md` do projeto.
- Atualiza `.gitignore` com as entradas necessárias.

Para reinstalar sobrescrevendo tudo (inclusive dados do projeto):

```bash
npx @praxio/onboardingai-kit init --force
```

---

## Configuração do MCP

Depois do `init`, configure a integração com o Azure DevOps:

```bash
npx @praxio/onboardingai-kit setup-mcp
```

O assistente interativo vai pedir:

| Campo | Exemplo | Descrição |
|-------|---------|-----------|
| Organização ADO | `praxio` | Nome da org no Azure DevOps |
| Projetos | `BackendAPI, Frontend` | Projetos ADO separados por vírgula |
| Autenticação | `az cli` ou `PAT` | Modo de autenticação |
| Caminho dos projetos locais | `C:\Projetos` | Raiz onde seus repos ficam |
| Pasta de briefings | `C:\Briefings` | Onde salvar análises de cards localmente |
| Repositórios relacionados | (opcional) | Repos complementares do mesmo sistema |

Ao final, gera:
- `.claude/.local-config.json` — configuração local (gitignored)
- `.mcp.json` — servidor MCP do Azure DevOps para o Claude Code (gitignored)

**Reinicie o Claude Code** após o `setup-mcp` para carregar o servidor MCP.

---

## Primeiros passos

### 1. Faça o onboarding do repositório

Dentro do Claude Code, no repositório instalado:

```
/bootstrap-repo NOME_DO_SISTEMA
```

Isso gera o **Speckit** — a memória institucional do sistema — com base em análise estática do código. Campos que não consegue inferir ficam marcados como `[DRAFT]` para você preencher.

### 2. Refine cards antes da sprint

Durante a cerimônia de refinamento:

```
/refine-card 54841
```

O agente lê o card no Azure (USER STORY `54841`) e toda a hierarquia acima (FEATURE, EPIC), analisa o código relacionado no repositório local e posta um comentário técnico diretamente na task — arquivos prováveis, riscos, estimativa, sugestões de teste.

### 3. Trabalhe no desenvolvimento

Para bugs:
```
/analyze-bug 54841
```

Para features:
```
/feature 54841
```

---

## Comandos CLI

Executados via `npx` no terminal, fora do Claude Code.

### `init`

```bash
npx @praxio/onboardingai-kit init
npx @praxio/onboardingai-kit init --force
```

Instala ou atualiza o kit no repositório atual. `--force` sobrescreve inclusive `.speckit/` e `.oai-flow/`.

### `setup-mcp`

```bash
npx @praxio/onboardingai-kit setup-mcp
```

Configura a integração com Azure DevOps de forma interativa. Gera `.mcp.json` e `.claude/.local-config.json`. Pode ser re-executado para atualizar configurações.

---

## Slash Commands

Executados dentro do **Claude Code** (comece digitando `/`).

> **{ID}** nos exemplos = ID numérico da USER STORY ou FEATURE no Azure DevOps (ex: `54841`). Não é o número do SIM/PSE.

---

### `/bootstrap-repo`

```
/bootstrap-repo NOME_DO_SISTEMA [--stack dotnet|node|react]
```

**Quando usar:** primeira vez que um dev abre o Claude Code em um repositório.

Faz análise estática do repo (estrutura, hotspots do git, TODOs, anti-patterns suspeitos), pergunta se há repositórios complementares (frontend, libs compartilhadas), e gera o Speckit inicial em `.speckit/`. Campos não inferíveis ficam como `[DRAFT]`.

**Dica:** após o bootstrap, preencha os `[DRAFT]` em `.speckit/domain/system-overview.md` com o dev sênior do projeto. Quanto mais completo, mais precisa a análise dos agentes.

---

### `/refine-card`

```
/refine-card 54841
```

**Quando usar:** cerimônia de refinamento, antes da sprint.

Lê a task e toda a hierarquia (EPIC → FEATURE → USER STORY → tasks filhas) no Azure DevOps, analisa o código relacionado no repositório local e posta um comentário técnico na task com:

- Entendimento da solicitação (SIM/PSE e contexto de negócio)
- Arquivos e módulos prováveis de serem alterados
- Dependências e riscos
- Estimativa: P / M / G / GG
- Sugestões de casos de teste para o QA
- Repositórios adicionais envolvidos (se detectados)

O comentário fica salvo na task para uso do dev executor — evita análise duplicada na hora de executar.

---

### `/analyze-bug`

```
/analyze-bug 54841
```

**Quando usar:** início do trabalho em uma correção de bug.

**Fluxo:**
1. Busca a task e navega a hierarquia no Azure DevOps.
2. Lê análise de refinamento prévia (se houver comentário do `/refine-card`).
3. Consulta o Speckit: known issues, diagnostic guide, risk map, naming guide.
4. Formula hipóteses explícitas (H1/H2/H3) com probabilidade antes de abrir qualquer arquivo.
5. Investiga em ordem de probabilidade.
6. Determina a root cause com **arquivo:linha + trecho de código**.
7. Mapeia o blast radius (impact-analyzer): módulos afetados, banco, integrações, outros repos.

⚡ **Checkpoint 1** — apresenta root cause e estratégia. Aguarda sua aprovação antes de continuar.

---

### `/generate-fix`

```
/generate-fix 54841
```

**Quando usar:** após aprovar o Checkpoint 1.

**Fluxo:**
1. Valida políticas (sem SQL concatenado, sem credencial hardcoded).
2. Aciona `architecture-agent` se o fix é de alto risco (arquivo ALTO no risk-map, múltiplos módulos, mudança de interface pública).
3. Pergunta a **sigla do módulo** (ex: `FLP`) — sempre confirma com você, nunca assume.
4. Propõe o branch no padrão Praxio: `feature/FLP_SIM_94457` ou `hotfix/FLP_SIM_94457`.
5. Escreve o **teste que falha** (RED) antes de qualquer código.
6. Implementa o mínimo para o teste passar (GREEN).
7. Executa gate check (build/testes). Non-zero exit = para.
8. Commita no formato Praxio.

⚡ **Checkpoint 2** — apresenta o patch para sua revisão.

---

### `/run-regression`

```
/run-regression 54841
```

**Quando usar:** após aprovar o Checkpoint 2.

Valida que o ciclo RED→GREEN foi executado, executa a suíte de testes completa, escreve testes complementares (edge cases, cenários do impact report) e verifica a qualidade das assertions.

---

### `/open-pr`

```
/open-pr 54841
```

**Quando usar:** após validação dos testes.

Gera o PR no Azure DevOps com:
- Título no padrão Praxio: `feat: FLP_SIM_94457 #54841`
- Descrição completa com root cause, solução, arquivos alterados e como testar
- Links para as tasks (USER STORY + FEATURE)
- Preenchimento automático da **task de fechamento de desenvolvimento** na hierarquia do Azure
- Rollback plan em `.oai-flow/delivery/54841-rollback-plan.md`

⚡ **Checkpoint 3** — aguarda aprovação do PR no Azure DevOps.

---

### `/release-check`

```
/release-check 54841
```

**Quando usar:** após aprovação do PR.

Verifica os quality gates:
- PR aprovado e pipeline de CI verde
- Dentro da janela de release (Seg–Qui 09–17h, Sex 09–12h apenas hotfix)
- Aprovações necessárias pela severidade (P1: tech lead; P2: dev + tech lead; P3/P4: dev)

Gera o release package com instrução de deploy, mudanças de banco e o que monitorar pós-deploy.

⚡ **Checkpoint 4** — aguarda confirmação do deploy antes de encerrar.

**Pós-deploy:** aciona o `learning-agent` automaticamente — atualiza o Speckit com o conhecimento gerado no ticket e fecha a task no Azure.

---

### `/feature`

```
/feature 54841
```

**Quando usar:** desenvolvimento de uma feature nova (não é bug).

Auto-dimensiona por complexidade:

| Tamanho | Critério | Fluxo |
|---------|---------|-------|
| **S** — Small | < 4h, 1 módulo, sem banco | 1 checkpoint + execução |
| **M** — Medium | 4–16h, até 3 módulos | 1 checkpoint + execução |
| **L** — Large | > 16h ou múltiplos módulos com dependências | 2 checkpoints: escopo + plano de tasks |

Para todos os tamanhos: lê a análise de refinamento prévia se disponível, propõe escopo, aguarda aprovação, implementa com RED→GREEN por task, gera PR e fecha o ciclo com `/release-check`.

---

### `/review-pr`

```
/review-pr 42
```

**Quando usar:** revisar o PR de um colega.

Busca o PR no Azure DevOps, lê a task associada para entender o requisito e analisa o diff em 4 dimensões:

1. **Funcionalidade** — o código resolve o que a task pede? Critérios de aceite cobertos?
2. **Qualidade** — anti-patterns, SQL concatenado, credenciais, catches vazios?
3. **Padrões Praxio** — branch e commit no formato correto? Task de fechamento preenchida?
4. **Testes** — cobertura dos cenários? Assertions específicas? Nenhum teste enfraquecido?

Gera relatório com veredicto: **APROVADO / APROVADO COM RESSALVAS / SOLICITAR MUDANÇAS**. Pode postar como comentário no PR via MCP.

---

### `/update-speckit`

```
/update-speckit
/update-speckit --since 2026-05-01
```

**Quando usar:** semanalmente, ou após uma sprint encerrada.

Analisa mudanças recentes no repositório (novos hotspots, TODOs adicionados, configs alteradas, work items fechados no Azure) e atualiza o Speckit. Registra um changelog em `.speckit/incidents/speckit-updates.md`.

---

## Fluxos de trabalho

### Bug Flow (fluxo completo)

```
/analyze-bug {ID}
    └─ busca task + hierarquia Azure
    └─ consulta Speckit
    └─ root cause com arquivo:linha
    └─ blast radius + risco
    └─ ⚡ CHECKPOINT 1

/generate-fix {ID}
    └─ [architecture-agent se necessário]
    └─ propõe branch → RED → GREEN → VERIFY
    └─ commit no formato Praxio
    └─ ⚡ CHECKPOINT 2

/run-regression {ID}
    └─ RED→GREEN confirmado
    └─ testes complementares

/open-pr {ID}
    └─ PR no Azure com título/descrição padrão Praxio
    └─ linka tasks + preenche fechamento de dev
    └─ ⚡ CHECKPOINT 3 (review no Azure)

/release-check {ID}
    └─ quality gates
    └─ ⚡ CHECKPOINT 4 (confirme o deploy)
    └─ learning-agent → Speckit atualizado → task fechada
```

### Feature Flow

```
/feature {ID}
    └─ lê task + refinamento prévio
    └─ especificação + sizing (S/M/L)
    └─ ⚡ CHECKPOINT 1
    └─ [plano de tasks se L] → ⚡ CHECKPOINT 2
    └─ RED→GREEN por task
    └─ /open-pr → /release-check
```

### Refinamento (cerimônia)

```
Para cada item da próxima sprint:
  /refine-card {ID}
      └─ lê task + hierarquia
      └─ analisa código
      └─ posta análise no Azure
```

---

## Padrões da Praxio

### Branch

| Origem | Formato | Exemplo |
|--------|---------|---------|
| `develop` / `feature` | `feature/{SIGLA}_{SIM\|PSE}_{N}` | `feature/FLP_SIM_94457` |
| `master` / `main` / `hotfix` | `hotfix/{SIGLA}_{SIM\|PSE}_{N}` | `hotfix/CGS_PSE_79548` |

- `SIGLA` — sigla do módulo em maiúsculas (ex: `FLP`, `CTR`, `CGS`). O agente sempre pergunta — nunca assume.
- `SIM` / `PSE` — tipo da solicitação do SAC.
- `N` — número da solicitação gerado pelo SAC.

### Commit

```
{feat|fix}: {SIGLA}_{SIM|PSE}_{numero} #{ID_USER_STORY}

{descrição breve do que foi feito}

US: #{ID_FEATURE}
```

**Exemplos:**

```
feat: FLP_SIM_94457 #54841

Adicionado cálculo de juros compostos no módulo de boletos

US: #54840
```

```
fix: CGS_PSE_79548 #54841

Corrigido timeout em chamadas ao serviço de CEP

US: #54840
```

### Pull Request

- **Título:** igual à primeira linha do commit — `feat: FLP_SIM_94457 #54841`
- **Descrição:** conteúdo completo do commit + arquivos alterados + passos para testar
- **Links:** PR linkado à USER STORY e à FEATURE no Azure DevOps
- Política de reviewers é gerenciada pelo Azure DevOps — o kit não interfere nisso

---

## Agentes disponíveis

Os agentes são ativados automaticamente pelos slash commands. Você também pode invocá-los diretamente pelo nome se quiser acionar um passo específico.

| Agente | Ativado por | O que faz |
|--------|------------|-----------|
| `azure-card-refiner` | `/refine-card` | Analisa task no Azure, analisa código, posta comentário técnico na task |
| `bug-investigator` | `/analyze-bug` | Determina root cause com evidências de código (arquivo:linha obrigatório) |
| `impact-analyzer` | `/analyze-bug` | Mapeia blast radius, classifica risco, identifica repos adicionais afetados |
| `architecture-agent` | `/generate-fix` (condicional) | Valida abordagem contra ADRs e policies antes de implementar |
| `builder-agent` | `/generate-fix`, `/feature` | Implementa o patch mínimo com RED→GREEN, branch e commit no padrão Praxio |
| `test-validator` | `/run-regression` | Confirma RED→GREEN, escreve testes complementares, executa gate check |
| `pr-generator` | `/open-pr` | Cria PR no Azure com formato Praxio e preenche task de fechamento de dev |
| `release-agent` | `/release-check` | Verifica quality gates, janela de release e gera release package |
| `learning-agent` | `/release-check` pós-deploy | Atualiza o Speckit com aprendizados do ticket, registra métricas, fecha task |
| `pr-reviewer` | `/review-pr` | Revisa PRs de colegas em 4 dimensões: funcional, qualidade, padrões, testes |

---

## O Speckit — memória institucional

O Speckit é a pasta `.speckit/` — ela fica no repositório e cresce a cada ticket encerrado. Quanto mais tickets, mais precisa a análise dos agentes.

```
.speckit/
  domain/
    system-overview.md     ← módulos, integrações, repos relacionados, conhecimento tribal
    naming-guide.md        ← nomes que enganam, glossário, enums críticos
    diagnostic-guide.md    ← tabela sintoma → suspeito imediato (cresce com cada bug)
  architecture/
    architecture-overview.md  ← padrão arquitetural, componentes, débito técnico
    risk-map.md               ← hotspots classificados por risco (ALTO/MÉDIO/BAIXO)
  known-issues/
    known-issues.md       ← padrões de bug confirmados com fix padrão
    anti-patterns.md      ← o que não replicar (AP-001, AP-002...)
    gray-zones.md         ← ambiguidades onde não há resposta única
  decisions/
    adr-registry.md       ← índice de ADRs
    ADR-NNN-*.md          ← decisões arquiteturais individuais
  business-rules/
    business-rules.md     ← regras de negócio com impacto técnico
  incidents/
    metrics-feed.jsonl    ← métricas por ticket (append-only)
    speckit-updates.md    ← changelog de atualizações
```

**Como o Speckit cresce:**
- `/bootstrap-repo` → gera a estrutura inicial com análise estática.
- `learning-agent` → enriquece automaticamente após cada deploy.
- `/update-speckit` → atualiza com mudanças recentes do repositório.
- Você pode editar manualmente qualquer arquivo a qualquer momento.

---

## Múltiplos repositórios

Alguns cenários envolvem mais de um repositório — mudança de contrato de API que afeta o frontend, alteração em lib compartilhada, integração entre serviços. O kit lida com isso de forma **opcional e situacional**.

### Como funciona

Os agentes detectam sinais de envolvimento de outros repos durante a análise (menção a frontend/backend, contratos, libs) e seguem este protocolo:

1. Verifica `knownRepos` em `.claude/.local-config.json` — se o repo estiver cadastrado com caminho local, usa direto.
2. Se não estiver cadastrado, pergunta: *"Identifiquei que [X] pode estar envolvido. Você tem o caminho local?"*
3. Se você fornecer → analisa/implementa nesse repo também.
4. Se você disser que não é necessário → registra como observação e segue.
5. **Nunca** modifica outro repo sem confirmação explícita sua.

### Cadastrar repos relacionados

Durante o `setup-mcp` o assistente pergunta se você quer cadastrar repos relacionados. Você também pode editar manualmente:

```json
// .claude/.local-config.json
"knownRepos": [
  {
    "name": "Frontend",
    "path": "C:\\Projetos\\App.Frontend",
    "type": "frontend",
    "description": "SPA React do módulo FLP"
  },
  {
    "name": "SharedLib",
    "path": "C:\\Projetos\\App.Shared",
    "type": "library",
    "description": "Contratos e DTOs compartilhados"
  }
]
```

O `/bootstrap-repo` também pergunta sobre repos complementares e oferece adicioná-los ao `knownRepos` automaticamente, incluindo uma seção "Repositórios Relacionados" no `system-overview.md`.

---

## Políticas e hard stops

As políticas em `.claude/policies/` são regras que os agentes não podem ignorar. Violações bloqueiam o pipeline.

### Hard stops absolutos

| Código | Regra | Consequência |
|--------|-------|-------------|
| AP-001 | Credencial hardcoded em qualquer arquivo | Bloqueado pelo architecture-agent |
| AP-002 | SQL construído por concatenação de string | Bloqueado pelo architecture-agent |
| AP-003 | `catch` vazio que engole exceção | Sinalizado como bloqueante |
| AP-004 | Commit direto em `main`/`master`/`develop` sem PR | Recusado pelo builder-agent |

### Janelas de release (release-policy)

| Dia | Janela | Observação |
|-----|--------|-----------|
| Segunda | 10h–16h | Evitar início do dia |
| Terça–Quinta | 09h–17h | Janela padrão |
| Sexta | 09h–12h | Apenas hotfix P1/P2 após 12h |
| Sábado–Domingo | ❌ | Sem deploy |

Fast-track disponível para P1 com aprovação do tech lead.

### Produção

Os agentes **nunca** executam comandos em servidores de produção, modificam configurações fora do pipeline ou acessam banco de produção diretamente. Forneça logs e evidências no chat para investigação.

---

## Estrutura de arquivos

Após `npx @praxio/onboardingai-kit init`:

```
.claude/                  ← kit-managed (atualizado a cada init)
  oai-kit.md              ← instruções principais carregadas pelo Claude
  agents/                 ← 10 agentes especializados
  commands/               ← slash commands
  workflows/              ← fluxos de trabalho
  policies/               ← políticas e hard stops
  .local-config.json      ← sua configuração local (gitignored)

.speckit/                 ← user-owned (nunca sobrescrito pelo kit)
  domain/                 ← contexto do sistema
  architecture/           ← decisões arquiteturais e risk map
  known-issues/           ← bugs conhecidos e anti-patterns
  decisions/              ← ADRs
  business-rules/         ← regras de negócio
  incidents/              ← métricas e changelog

.oai-flow/               ← user-owned (artifacts dos tickets)
  analysis/              ← BugReports, ImpactReports
  design/                ← ArchGuidance
  delivery/              ← Patches, ValidationReports, PRs, ReleasePackages
  discovery/             ← artifacts de features

scripts/                 ← kit-managed
  bootstrap-speckit.sh   ← análise estática para gerar o Speckit
  init-ticket.sh         ← inicializa workspace de um ticket
  update-speckit.sh      ← atualiza o Speckit com mudanças recentes

docs/
  onboarding/
    squad-member-guide.md ← guia resumido para novos devs no kit

CLAUDE.md                ← contém @.claude/oai-kit.md (injetado pelo init)
.mcp.json                ← configuração do servidor MCP Azure DevOps (gitignored)
```

---

## Configuração local

O arquivo `.claude/.local-config.json` (gitignored, por dev) centraliza toda a configuração pessoal:

```json
{
  "schemaVersion": 1,
  "provider": "azureDevOps",
  "localAppsRoot": "C:\\Projetos",
  "briefingDir": "C:\\Briefings",
  "azureDevOps": {
    "authMode": "azcli",
    "org": "praxio",
    "projects": ["BackendAPI", "Frontend"]
  },
  "knownRepos": [
    {
      "name": "Frontend",
      "path": "C:\\Projetos\\App.Frontend",
      "type": "frontend",
      "description": "SPA React do módulo FLP"
    }
  ]
}
```

Para reconfigurar: `npx @praxio/onboardingai-kit setup-mcp`

---

## Atualizar o kit

Quando uma nova versão for publicada, dentro de qualquer repositório que já tem o kit:

```bash
npx @praxio/onboardingai-kit init
```

Isso atualiza `.claude/`, `scripts/` e `docs/` (kit-managed) sem tocar em `.speckit/` e `.oai-flow/` (seus dados).

---

## Perguntas frequentes

**O agente não encontrou o servidor MCP do Azure DevOps.**  
Rode `npx @praxio/onboardingai-kit setup-mcp` e reinicie o Claude Code. Verifique se `.mcp.json` existe na raiz do repositório.

**O agente está pedindo a sigla do módulo toda vez.**  
A sigla não é inferida automaticamente — o kit sempre confirma com você para evitar erros de branch/commit. Futuramente você pode cadastrar módulos conhecidos manualmente no `.local-config.json`.

**Posso usar o kit em um repositório que já tem um `CLAUDE.md` com conteúdo?**  
Sim. O `init` apenas adiciona `@.claude/oai-kit.md` ao final do `CLAUDE.md` existente, sem sobrescrever o conteúdo anterior.

**O Speckit gerado pelo `/bootstrap-repo` está com muitos `[DRAFT]`.**  
Isso é esperado na primeira vez — a análise estática tem limites. Preencha `.speckit/domain/system-overview.md` junto com um dev sênior do projeto. Com 10+ `[DRAFT]`, sugerimos uma sessão de 30min para preencher os campos críticos.

**Posso rodar `/refine-card` durante a execução, não apenas no refinamento?**  
Pode, mas a intenção é que na execução o dev use `/analyze-bug` ou `/feature` — que já fazem suas próprias análises (e leem os comentários postados pelo `/refine-card`). Usar ambos no mesmo ticket não é problema, mas é redundante.

**O kit modifica arquivos em outros repositórios sem eu pedir?**  
Não. Para repos adicionais, o agente sempre pergunta antes de fazer qualquer leitura ou modificação. Você pode recusar e ele registra como observação.

---

## Licença

MIT — Praxio
